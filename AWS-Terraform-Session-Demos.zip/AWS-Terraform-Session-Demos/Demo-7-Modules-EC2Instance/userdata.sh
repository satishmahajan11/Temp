#!/bin/bash
sudo su
yum update -y
yum install httpd  -y 
service httpd start
chkconfig httpd on
cd /var/www/html
echo "Welcome to my 1st WebPage on Cloud EC2 linux instance " > index.html