#!/bin/bash
sudo su
yum update -y
sudo amazon-linux-extras install ${JDKVERSION} -y
java -version
cd /home/ec2-user/
mkdir /home/ec2-user/SampleRestApp
cd /home/ec2-user/SampleRestApp/
wget ${WARFILEPATH}
java -jar SampleRestApp.war
