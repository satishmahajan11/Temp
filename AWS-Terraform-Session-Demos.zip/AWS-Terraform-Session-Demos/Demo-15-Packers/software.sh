#!/bin/bash
sudo su
yum update -y
sudo amazon-linux-extras install java-openjdk11 -y
java -version
cd /home/ec2-user/
mkdir /home/ec2-user/SampleRestApp
cd /home/ec2-user/SampleRestApp/
wget https://samplerestappbucket-s3.s3.ap-south-1.amazonaws.com/SampleRestApp.war
